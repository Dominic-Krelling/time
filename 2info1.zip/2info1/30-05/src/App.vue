<template>
  <header>Home | Jogadores | Time</header>
  <main>main</main>
  <footer>Rodapé</footer>
</template>

<style>
@import "@/assets/base.css";

#app {
  max-width: 1280px;
  margin: 0 auto;
  /* padding: 2rem; */
  height: 100vh;
  font-weight: normal;
}
header,
footer {
  background-color: rgb(59, 59, 137);
  color: white;
  height: 15%;
  font-size: 1.3rem;
  display: flex;
  align-items: center;
  padding-left: 2rem;
}
main {
  height: 100%;
}
</style>
